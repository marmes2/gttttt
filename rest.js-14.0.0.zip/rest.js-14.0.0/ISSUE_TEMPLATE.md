Please provide a minimal code sample to reproduce the issue if possible.
