# Scripts

The code in this folder are not part of the `@octokit/rest` library.

The scripts instead do 3 different things

1. Generate API Docs into `doc/` folder
2. Generate Typescript definitions into `index.d.ts`
2. Generate Flow type definitions into `index.js.flow`
